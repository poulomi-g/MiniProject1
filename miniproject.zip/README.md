# MiniProject1
  Poulomi Ganguly
  -poulomi
  
  Rahul Korde
  -rkorde

  wE DECLARE WE HAVE NOT COLLABOPRATED WITH ANYONE
